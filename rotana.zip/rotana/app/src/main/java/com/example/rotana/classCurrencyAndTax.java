package com.example.rotana;

public class classCurrencyAndTax {
    public String currency ="";
    public double tax=0;
}
