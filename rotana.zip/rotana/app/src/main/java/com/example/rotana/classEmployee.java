package com.example.rotana;

public class classEmployee {
    public String  Fname="";
    public String  Lname="";
    public String  regisetDate="";
    public String  email="";
    public String empPhone="";
    public String  empType="";
    public String address="";
    public String jopType="";
    public double sal=0;


    public boolean warehousea=false,
            onlineReservation=false,
            tableResev=false,
            takeAway=false,
            delevery=false,
            addpayment=false,
            cashWork=false,
            empExt=false;
}
