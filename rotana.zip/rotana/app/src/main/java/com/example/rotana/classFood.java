package com.example.rotana;

public class classFood {
    public String name  ;
    public String title ;
    public String price ;
    public String date  ;
}
