package com.example.rotana;

public class classSupplier {
    public String name ="",email="",phone="",id ="";
}
