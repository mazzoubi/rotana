package com.example.rotana;

public class classNotification {
    public String title="",
    date="",time="",desc="",state="0",id="";
}
