package com.example.rotana;

public class classRating {
    public String name="",note="",rate="";
}
