package com.example.rotana;

public class classVipUsers {
    public String name="",phone="",email="",id="",desc="";
}
