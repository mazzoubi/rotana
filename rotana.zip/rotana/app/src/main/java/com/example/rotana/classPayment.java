package com.example.rotana;

public class classPayment {
    public double pay =0;
    public String date ="";
    public String description="" ;
    public String time ="";
    public String emp="";
}
