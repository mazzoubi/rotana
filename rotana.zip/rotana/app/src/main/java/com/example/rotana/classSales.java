package com.example.rotana;

public class classSales {
    public double sale=0;
    public double cost=0;
    public String date= "";
    public String time    = "";
    public String item    = "";
    public String subItem = "";
    public String empEmail= "";

}
