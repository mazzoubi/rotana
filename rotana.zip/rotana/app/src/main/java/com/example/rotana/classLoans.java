package com.example.rotana;

public class classLoans {
    public String empEmail="",loanId="";
    public double totelLoan=0,loan=0,repyment=0;
}
