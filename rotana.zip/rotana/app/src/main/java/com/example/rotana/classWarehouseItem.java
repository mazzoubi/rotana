package com.example.rotana;

public class classWarehouseItem {

    public String item ;
    public String quantity;
    public String quantityType;
    public String supplier="";
}
