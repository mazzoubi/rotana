package com.example.rotana;

public class classSubItem {
    public String item="",itemId="",subItem="",image="",point="";
    public String kitchen="", description="";
    public String Ar_description="", Ar_item="", Ar_subItem="",cost="0";
    public double price=0;
}
