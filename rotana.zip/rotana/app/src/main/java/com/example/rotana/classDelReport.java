package com.example.rotana;

public class classDelReport {
    public String date_time=""
            ,delivery_sum=""
            ,order_num=""
            ,order_sum="";
}
