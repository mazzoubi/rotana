package com.example.rotana;

public class classCloseOpenCash {
    public String empEmail="",dateOpen="",dateAndTimeOpen="",dateAndTimeClose="", note="";
    public double floor=0,total=0;
    public double sold=0,paid=0;
}
