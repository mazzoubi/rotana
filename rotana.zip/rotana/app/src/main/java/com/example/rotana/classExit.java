package com.example.rotana;

public class classExit {
    public String date="";
    public String description="";
    public String email="";
    public String time="";
    public String extID="";


}
