package com.example.rotana;

public class classItem {
    public String itemName="",itemId="";
}
