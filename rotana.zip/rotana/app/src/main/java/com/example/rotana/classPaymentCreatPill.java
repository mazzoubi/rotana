package com.example.rotana;

public class classPaymentCreatPill {
    public String empEmail="",pillNumber="",items="",numberOfElement="",supplier="",date="",coast="",desc="";
}
